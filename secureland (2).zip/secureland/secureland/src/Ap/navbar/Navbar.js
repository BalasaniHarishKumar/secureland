import React from 'react'
import logo from '../images/ap_logo.png'
import cm from '../images/ap_cm.jpg'
import './Navbar.css'
const Navbar = () => {
  return (
    <div className='container sticky-top'>
      <div className='row mt-4'>
        <div className='col'>
          <img src={logo} alt="ap logo" width="100px" /> 
        </div>
        <div className='col-7 mt-4'>
            <h4>Secure Land Management</h4>
            <h4>Government of Andhra Pradesh</h4>
        </div>
        <div className='col-3 text-center color'>
            <img src={cm} alt="ap cm" width="100px"/>
            <div className='col' style={{textAlign:"center"}}>
            <h5>Sri Nara Chandrababu Naidu</h5>
            <h5>Hon'ble Chief Minister</h5>
            <h5>of Andhra Pradesh</h5>
            </div>
        </div>
      </div>
    </div>
  )
}

export default Navbar