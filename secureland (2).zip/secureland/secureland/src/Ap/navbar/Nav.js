// src/Navbar.js
import React from 'react';
import './Nav.css'
import logo from '../images/ap_logo.png'; 
import ministerImage from '../images/img2.jpg';
import chiefMinisterImage from '../images/apcm.jpeg'; 

const Nav = () => {
  return (
    <div className="navbar sticky-top">
      <div className="navbar-left">
        <img src={logo} alt="Logo" className="logo" />
        <h1 className="title">Secure Land Management</h1>
      </div>
      <div className="navbar-right">
        <div className="profile">
          <img src={ministerImage} alt="Minister" className="profile-image" />
          <div className="profile-info">
            <p className="profile-name">Minister Name</p>
            <p className="profile-designation">Designation</p>
          </div>
        </div>
        <div className="profile">
          <img src={chiefMinisterImage} alt="Chief Minister" className="profile-image" />
          <div className="profile-info">
            <p className="profile-name"> Sri Nara Chandrababu Naidu</p>
            <p className="profile-designation">Chief Minister - AP</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Nav;
