import React from 'react'

const OfficialRegistration = () => {
  return (
    <div>OfficialRegistration</div>
  )
}

export default OfficialRegistration