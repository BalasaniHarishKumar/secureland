import React from 'react'

const UserRegPage2 = () => {
  return (
    <div>
        
    </div>
  )
}

export default UserRegPage2