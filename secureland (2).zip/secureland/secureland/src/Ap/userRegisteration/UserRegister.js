import React, { useContext } from 'react'
import Nav from '../navbar/Nav'
import './UserRegister.css'
import { useForm } from 'react-hook-form'
import * as yup from "yup"
import {yupResolver} from '@hookform/resolvers/yup'
import { AddressContext } from '../mainPage/MainPage'
import Footer from '../footer/Footer'

const UserRegister = (props) => {

  const {selectedDistrict,selectedMandal,selectedVillage} = useContext(AddressContext)
  const schema = yup.object().shape({
    regNo:yup.number().positive().integer().required(),
    fullName:yup.string().required(),
    casteCode:yup.string().required(),
    aadhar:yup.number().positive().integer().required(),
    district:yup.string(),
    mandal:yup.string(),
    village:yup.string(),  
    mobile:yup.number().positive().integer().required()
  })

  const {register, handleSubmit,formState: {errors}} = useForm({
    resolver:yupResolver(schema)
  })
  const onSubmit = (data)=>{
    console.log("data is ",data)
    console.log("District ",selectedDistrict)
  }
  return (
    <div>
      <Nav />
      <div className='container'>
        <div className='application-center'>
          <h2 style={{color:"red",fontWeight:"bold"}}>User Application</h2>
          <div className='formsInput'>
           <form onSubmit={handleSubmit(onSubmit)}>
            Registration No: <input type="text" placeholder='Enter Registration No..' {...register('regNo')}/> <br /> <br/>
            Name of the Applicant: <input type="text" placeholder='Enter Full name..' {...register('fullName')}/> <br /> <br/>
            Caste Code: <input type="text" placeholder='Enter Caste Code..' {...register('casteCode')}/> <br /> <br/>
            Aadhaar: <input type="number" placeholder='Enter Your Aadhar No.' {...register('aadhar')}/> <br /> <br/> 
            <p>{errors.aadhar?.message}</p>
            Address: District: <input type='text' value={selectedDistrict} {...register('district')} readOnly/><br /> <br/>
            Mandal: <input type="text" value={selectedMandal} placeholder={selectedMandal} {...register('mandal')} readOnly/><br /> <br/>
            Village: <input type="text" value={selectedVillage} {...register('village')} readOnly/><br /> <br/>
            Mobile: <input type="number" placeholder='Mobile Number' {...register('mobile')}/><br /> <br/>
            <input type="submit" value="submit"/> &nbsp; &nbsp; &nbsp;
            <input type="reset"/>
           </form> 
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}

export default UserRegister