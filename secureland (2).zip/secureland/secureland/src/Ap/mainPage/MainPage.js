import React, { createContext, useContext } from 'react'
import './MainPage.css'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import Nav from '../navbar/Nav'
import Footer from '../footer/Footer'
export const AddressContext=createContext()
const MainPage = () => {
  // const [selectedDistrict, setSelectedDistrict] = useState('');
  // const [selectedMandal, setSelectedMandal] = useState('');
  // const [selectedVillage, setSelectedVillage] = useState('');

  const {selectedDistrict,setSelectedDistrict,selectedMandal,setSelectedMandal,selectedVillage,setSelectedVillage} = useContext(AddressContext)
  const [registrationType, setRegistrationType] = useState('');

  const districts = ['srikakulam', 'vizianagaram'];

  const mandals = {
    srikakulam: ['Rajam', 'Ranasthalam', 'Palasa', 'Mandasa', 'Gara'],
    vizianagaram: ['Bobbili', 'Parvathipuram', 'kothavalasa', 'Garividi', 'Bhogapuram'],
  };

  const villages = {
    'Rajam': ['Aaguru', 'Amaram', 'Boddam', 'Kancharam', 'Pogiri', 'Syampuram'],
    'Ranasthalam': ['Akkayapalem', 'Garikipalem', 'Gosam', 'Gudem', 'Kosta', 'Mentada'],
    'Palasa': ['Bantukottutu', 'Chinanchala', 'Gopalapuram', 'Govindapuram', 'Kajjola', 'Kesipuram'],
    'Mandasa': ['Baligam', 'Balajipuram', 'Allimeraka', 'Cheepi', 'Dabaru', 'Madhya'],
    'Gara': ['Ampolu', 'Deepavali', 'Gonti', 'Korni', 'Nizamabad', 'Sativada'],
    'Bobbili': ['Chintada', 'Karada', 'Pakki', 'Penta', 'Piridi', 'Vangara'],
    'Parvathipuram': ['Adaru', 'Kora', 'Krishnapalle', 'Mulaga', 'Putturu', 'Tonki'],
    'kothavalasa': ['Dathi', 'Devada', 'Musiram', 'Narapam', 'Relli', 'Uttarapalle'],
    'Garividi': ['Bondapalle', 'Palavalasa', 'Konuru', 'Seripeta', 'Sivaram', 'Thatiguda'],
    'Bhogapuram': ['Gudivada', 'Kancheru', 'Jaggayyapeta', 'Nandhigama', 'Ravada', 'Munjeru'],
  };

  const handleDistrictChange = (e) => {
    setSelectedDistrict(e.target.value);
    setSelectedMandal('');
    setSelectedVillage('');
    setRegistrationType('');
  };

  const handleMandalChange = (e) => {
    setSelectedMandal(e.target.value);
    setSelectedVillage('');
    setRegistrationType('');
  };
  return (
    <div>
      <Nav />
      <div className='container pt-5 mt-3'>
      <div className="home-page">
      <div className="form-container">
        <h2>Select Your Location</h2>
        <form>
          <div className="form-group">
            <label htmlFor="district">District:</label>
            <select
              id="district"
              value={selectedDistrict}
              onChange={handleDistrictChange}
            >
              <option value="">Select District</option>
              {districts.map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="mandal">Mandal:</label>
            <select
              id="mandal"
              value={selectedMandal}
              onChange={handleMandalChange}
              disabled={!selectedDistrict}
            >
              <option value="">Select Mandal</option>
              {selectedDistrict &&
                mandals[selectedDistrict].map((mandal) => (
                  <option key={mandal} value={mandal}>
                    {mandal}
                  </option>
                ))}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="village">Village:</label>
            <select
              id="village"
              value={selectedVillage}
              onChange={(e) => setSelectedVillage(e.target.value)}
              disabled={!selectedMandal}
            >
              <option value="">Select Village</option>
              {selectedMandal &&
                villages[selectedMandal].map((village) => (
                  <option key={village} value={village}>
                    {village}
                  </option>
                ))}
            </select>
          </div>
          {selectedDistrict && selectedMandal && selectedVillage && (
            <div className="form-group">
              <label htmlFor="registrationType">Registration Type:</label>
              <select
                id="registrationType"
                value={registrationType}
                onChange={(e) => setRegistrationType(e.target.value)}
              >
                <option value="">Select Registration Type</option>
                <option value="applicant">Applicant Registration</option>
                <option value="govtOfficial">Govt Officials Registration</option>
              </select>
              {registrationType && (
                <div className="form-group button">
                <button type="button" className='btn btn-info'> <Link to="/userReg" style={{textDecoration:"none"}}>Register</Link></button>
                </div>
              )}
            </div>
          )}
        </form>
      </div>
    </div>
      </div>
      <Footer />
    </div>
  )
}

export default MainPage