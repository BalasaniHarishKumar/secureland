import React, { useState } from 'react';
import './App.css'; // Assuming you have a separate CSS file for styling

const LandTypeSelector = () => {
  const [landType, setLandType] = useState('');
  const [landSubtype, setLandSubtype] = useState('');
  const [subtypeOptions, setSubtypeOptions] = useState([]);

  // Define options for the first dropdown
  const landTypeOptions = [
    { label: 'Scheduled Lands', value: 'scheduled' },
    { label: 'Non Scheduled Lands', value: 'nonScheduled' }
  ];

  // Define options for the second dropdown based on the first dropdown selection
  const landSubtypeOptions = {
    scheduled: [
      { label: 'Scheduled Areas', value: 'scheduledAreas' },
      { label: 'Tribal Sub Plan Areas', value: 'tribalSubPlanAreas' },
      { label: 'Residential and Forest Areas', value: 'residentialAndForestAreas' }
    ],
    nonScheduled: [
      { label: 'Urban Areas', value: 'urbanAreas' },
      { label: 'Rural Non Scheduled Areas', value: 'ruralNonScheduledAreas' },
      { label: 'Agriculture and Non Agriculture Lands', value: 'agricultureAndNonAgricultureLands' },
      { label: 'Forest Areas Outside Scheduled Areas', value: 'forestAreasOutsideScheduledAreas' },
      { label: 'Government and Public Lands', value: 'governmentAndPublicLands' }
    ]
  };

  // Handle change in the first dropdown
  const handleLandTypeChange = (e) => {
    const selectedLandType = e.target.value;
    setLandType(selectedLandType);
    if (selectedLandType === 'scheduled') {
      setSubtypeOptions(landSubtypeOptions.scheduled);
    } else if (selectedLandType === 'nonScheduled') {
      setSubtypeOptions(landSubtypeOptions.nonScheduled);
    } else {
      setSubtypeOptions([]);
    }
    setLandSubtype(''); // Reset subtype selection when land type changes
  };

  // Handle change in the second dropdown
  const handleLandSubtypeChange = (e) => {
    const selectedLandSubtype = e.target.value;
    setLandSubtype(selectedLandSubtype);
  };

  return (
    <div className="container">
      <div className="dropdown-container">
        <label htmlFor="landTypeDropdown">Type of Land:</label>
        <select
          id="landTypeDropdown"
          value={landType}
          onChange={handleLandTypeChange}
        >
          <option value="">Select...</option>
          {landTypeOptions.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      {landType && (
        <div className="dropdown-container">
          <label htmlFor="landSubtypeDropdown">Land Subtype:</label>
          <select
            id="landSubtypeDropdown"
            value={landSubtype}
            onChange={handleLandSubtypeChange}
          >
            <option value="">Select...</option>
            {subtypeOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      )}
    </div>
  );
};

export default LandTypeSelector;
