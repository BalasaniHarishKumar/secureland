import React from 'react';
import './App.css'; // Assuming you have a separate CSS file for global styles
import LandTypeSelector from './LandTypeSelector'; // Path to your LandTypeSelector component

function App() {
  const handleSubmit = () => {
    // Handle form submission logic here
    console.log('Form submitted!');
  };

  const handleReset = () => {
    // Handle form reset logic here
    console.log('Form reset!');
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Land Type Selector</h1>
      </header>
      <main className="App-main">
        <LandTypeSelector />
        <div className="button-container">
          <button className="submit-button" onClick={handleSubmit}>Submit</button>
          <button className="reset-button" onClick={handleReset}>Reset</button>
        </div>
      </main>
      <footer className="App-footer">
        {/* Optional footer content */}
      </footer>
    </div>
  );
}

export default App;
