// backend/server.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const Land = require('./models/land.model');

const app = express();
const port = 5000;

app.use(cors());
app.use(bodyParser.json());

// MongoDB connection
const mongoURI = 'mongodb://localhost:27017/landDetailsDB'; // Replace with your MongoDB connection string
mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const connection = mongoose.connection;
connection.once('open', () => {
  console.log('MongoDB database connection established successfully');
});

// Define your schema and model here (example)
const landSchema = new mongoose.Schema({
  typeOfLand: String,
  landType: String,
});

// Model
const Land = mongoose.model('Land', landSchema);

// API endpoints
// Create a new land entry
app.post('/lands', (req, res) => {
  const { typeOfLand, landType } = req.body;
  const newLand = new Land({ typeOfLand, landType });

  newLand.save()
    .then(() => res.json('Land added!'))
    .catch(err => res.status(400).json('Error: ' + err));
});

// Get all land entries
app.get('/lands', (req, res) => {
  Land.find()
    .then(lands => res.json(lands))
    .catch(err => res.status(400).json('Error: ' + err));
});

// Update a land entry by ID
app.put('/lands/:id', (req, res) => {
  Land.findById(req.params.id)
    .then(land => {
      land.typeOfLand = req.body.typeOfLand;
      land.landType = req.body.landType;

      land.save()
        .then(() => res.json('Land updated!'))
        .catch(err => res.status(400).json('Error: ' + err));
    })
    .catch(err => res.status(400).json('Error: ' + err));
});

// Delete a land entry by ID
app.delete('/lands/:id', (req, res) => {
  Land.findByIdAndDelete(req.params.id)
    .then(() => res.json('Land deleted.'))
    .catch(err => res.status(400).json('Error: ' + err));
});

app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
});
