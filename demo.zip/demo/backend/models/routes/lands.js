// backend/routes/lands.js
const express = require('express');
const router = express.Router();
const Land = require('../models/land.model');

// GET all lands
router.get('/', (req, res) => {
  Land.find()
    .then(lands => res.json(lands))
    .catch(err => res.status(400).json('Error: ' + err));
});

// POST new land
router.post('/', (req, res) => {
  const { typeOfLand, landType } = req.body;
  const newLand = new Land({ typeOfLand, landType });

  newLand.save()
    .then(() => res.json('Land added!'))
    .catch(err => res.status(400).json('Error: ' + err));
});

// GET land by ID
router.get('/:id', (req, res) => {
  Land.findById(req.params.id)
    .then(land => res.json(land))
    .catch(err => res.status(400).json('Error: ' + err));
});

// DELETE land by ID
router.delete('/:id', (req, res) => {
  Land.findByIdAndDelete(req.params.id)
    .then(() => res.json('Land deleted.'))
    .catch(err => res.status(400).json('Error: ' + err));
});

// PUT update land by ID
router.put('/:id', (req, res) => {
  Land.findById(req.params.id)
    .then(land => {
      land.typeOfLand = req.body.typeOfLand;
      land.landType = req.body.landType;

      land.save()
        .then(() => res.json('Land updated!'))
        .catch(err => res.status(400).json('Error: ' + err));
    })
    .catch(err => res.status(400).json('Error: ' + err));
});

module.exports = router;
